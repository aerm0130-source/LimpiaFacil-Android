LIMPIA FÁCIL - Android
======================

Qué hace
- No analiza automáticamente: el usuario pulsa "Analizar teléfono".
- Pide acceso amplio a archivos porque su función principal es administrar/analizar almacenamiento.
- Detecta duplicados exactos por SHA-256, no sólo por nombre.
- Marca archivos grandes (>500 MB), descargas viejas (>90 días), APK y comprimidos.
- No escanea Android/data ni Android/obb.
- Sólo marca en verde duplicados exactos fuera de carpetas Android.
- Mueve los archivos seleccionados a Documents/LimpiaFacil_Papelera en vez de borrarlos de inmediato.
- Permite restaurar desde la propia app.
- Sólo muestra hasta 100 resultados por categoría para mantener la interfaz rápida.
- Todo se procesa localmente. No usa Internet.

Compilar APK
1. Abrir esta carpeta en Android Studio.
2. Esperar la sincronización de Gradle.
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. El APK debug queda normalmente en app/build/outputs/apk/debug/app-debug.apk.

Probado por diseño para Android 11+; targetSdk 35 (Android 15).
