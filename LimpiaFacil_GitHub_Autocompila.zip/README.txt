LIMPIA FÁCIL 2.0 - Android
==========================

Funciones
- Análisis manual de archivos: no escanea automáticamente al abrir.
- Duplicados exactos por SHA-256.
- Archivos grandes (>500 MB), descargas viejas (>90 días), capturas viejas y APK/ZIP/RAR.
- Papelera propia con restauración.
- No entra a Android/data ni Android/obb.
- OCR manual y local para detectar capturas con TeamViewer, AnyDesk, RustDesk, Supremo, UltraViewer y Asistencia rápida.
- El OCR no guarda el texto reconocido, IDs ni contraseñas.
- Apps y memoria: muestra almacenamiento total, RAM global, apps que más ocupan, caché y último uso.
- Lista apps no usadas por 90+ días y abre la configuración de Android para administrar/desactivar/desinstalar.
- Android no permite medir de forma fiable la RAM exacta usada por cada otra app; la pantalla lo aclara.
- Sin permiso INTERNET.

Permisos especiales
1. Administrar todos los archivos: necesario para el análisis/limpieza del almacenamiento compartido.
2. Acceso de uso: necesario para estadísticas de almacenamiento y último uso de aplicaciones.

Rendimiento
- OCR sólo se ejecuta al pulsar “Revisar capturas (OCR)”.
- Máximo 900 imágenes por ejecución OCR, priorizando capturas, Descargas, WhatsApp/Telegram y Pictures.
- Máximo 100 resultados renderizados por categoría.
- Apps y memoria se calcula únicamente al pulsar el botón.

Compilación GitHub Actions
El workflow incluido compila app-debug.apk con Java 17, Android 35 y Gradle 8.9.
