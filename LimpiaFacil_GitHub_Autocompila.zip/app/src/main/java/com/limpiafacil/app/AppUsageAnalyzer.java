package com.limpiafacil.app;

import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.os.Process;
import android.os.storage.StorageManager;
import android.os.StatFs;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class AppUsageAnalyzer {
    private static final long DAY = 24L * 60L * 60L * 1000L;

    static final class DeviceStats {
        final long totalStorage;
        final long freeStorage;
        final long totalRam;
        final long availableRam;

        DeviceStats(long totalStorage, long freeStorage, long totalRam, long availableRam) {
            this.totalStorage = totalStorage;
            this.freeStorage = freeStorage;
            this.totalRam = totalRam;
            this.availableRam = availableRam;
        }
    }

    static final class AppRow {
        final String label;
        final String packageName;
        final long totalBytes;
        final long cacheBytes;
        final long lastUsed;
        final long firstInstall;
        final boolean systemApp;

        AppRow(String label, String packageName, long totalBytes, long cacheBytes,
               long lastUsed, long firstInstall, boolean systemApp) {
            this.label = label;
            this.packageName = packageName;
            this.totalBytes = totalBytes;
            this.cacheBytes = cacheBytes;
            this.lastUsed = lastUsed;
            this.firstInstall = firstInstall;
            this.systemApp = systemApp;
        }

        boolean unused90Days(long now) {
            if (systemApp) return false;
            if (now - firstInstall < 90L * DAY) return false;
            return lastUsed <= 0 || now - lastUsed >= 90L * DAY;
        }
    }

    static boolean hasUsageAccess(Context context) {
        try {
            AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    static DeviceStats deviceStats(Context context) {
        StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return new DeviceStats(stat.getTotalBytes(), stat.getAvailableBytes(), mi.totalMem, mi.availMem);
    }

    static List<AppRow> analyze(Context context) {
        if (!hasUsageAccess(context)) throw new IllegalStateException("usage_access_required");

        long now = System.currentTimeMillis();
        UsageStatsManager usageManager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        List<UsageStats> usage = usageManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 365L * DAY, now);
        Map<String, Long> lastUsed = new HashMap<>();
        if (usage != null) {
            for (UsageStats u : usage) {
                Long previous = lastUsed.get(u.getPackageName());
                if (previous == null || u.getLastTimeUsed() > previous) lastUsed.put(u.getPackageName(), u.getLastTimeUsed());
            }
        }

        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> apps;
        if (Build.VERSION.SDK_INT >= 33) {
            apps = pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0));
        } else {
            apps = pm.getInstalledApplications(0);
        }

        StorageStatsManager storageStats = (StorageStatsManager) context.getSystemService(Context.STORAGE_STATS_SERVICE);
        List<AppRow> rows = new ArrayList<>();
        for (ApplicationInfo ai : apps) {
            if (context.getPackageName().equals(ai.packageName)) continue;
            String label;
            try { label = pm.getApplicationLabel(ai).toString(); }
            catch (Exception e) { label = ai.packageName; }

            long total = 0;
            long cache = 0;
            try {
                StorageStats stats = storageStats.queryStatsForPackage(StorageManager.UUID_DEFAULT, ai.packageName, Process.myUserHandle());
                cache = stats.getCacheBytes();
                total = stats.getAppBytes() + stats.getDataBytes() + cache;
            } catch (Exception ignored) {
            }

            long installed = 0;
            try {
                PackageInfo pi;
                if (Build.VERSION.SDK_INT >= 33) pi = pm.getPackageInfo(ai.packageName, PackageManager.PackageInfoFlags.of(0));
                else pi = pm.getPackageInfo(ai.packageName, 0);
                installed = pi.firstInstallTime;
            } catch (Exception ignored) {
            }

            boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            rows.add(new AppRow(label, ai.packageName, total, cache,
                    lastUsed.getOrDefault(ai.packageName, 0L), installed, system));
        }
        rows.sort(Comparator.comparingLong((AppRow a) -> a.totalBytes).reversed());
        return rows;
    }
}
