package com.limpiafacil.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {

    private static final int C_BG = Color.rgb(7, 17, 31);
    private static final int C_CARD = Color.rgb(13, 29, 49);
    private static final int C_CARD_2 = Color.rgb(17, 38, 62);
    private static final int C_TEXT = Color.rgb(240, 246, 252);
    private static final int C_MUTED = Color.rgb(153, 171, 190);
    private static final int C_BLUE = Color.rgb(35, 199, 232);
    private static final int C_GREEN = Color.rgb(57, 211, 137);
    private static final int C_YELLOW = Color.rgb(246, 196, 68);
    private static final int C_RED = Color.rgb(255, 102, 112);

    private static final long LARGE_BYTES = 500L * 1024L * 1024L;
    private static final long OLD_DOWNLOAD_MS = 90L * 24L * 60L * 60L * 1000L;
    private static final long OLD_SCREENSHOT_MS = 90L * 24L * 60L * 60L * 1000L;
    private static final int MAX_VISIBLE = 100;
    private static final int MAX_OCR_IMAGES = 900;
    private static final String PREFS = "limpiafacil_prefs";
    private static final String PREF_TRASH = "trash_map";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean scanning = new AtomicBoolean(false);
    private final AtomicBoolean ocrScanning = new AtomicBoolean(false);
    private final AtomicBoolean appScanning = new AtomicBoolean(false);
    private final List<Candidate> allCandidates = Collections.synchronizedList(new ArrayList<>());
    private final List<FileInfo> lastScannedFiles = Collections.synchronizedList(new ArrayList<>());
    private final Set<String> selectedPaths = Collections.synchronizedSet(new HashSet<>());

    private LinearLayout root;
    private LinearLayout resultsContainer;
    private TextView permissionText;
    private TextView usagePermissionText;
    private TextView statusText;
    private TextView summaryText;
    private ProgressBar progress;
    private Button scanButton;
    private Button ocrButton;
    private Button appsButton;
    private Button trashButton;
    private Button selectGreenButton;
    private Button moveButton;
    private String activeCategory = Category.REMOTE_SCREENSHOT;
    private int protectedFolders = 0;
    private long scannedBytes = 0;
    private int scannedFiles = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        updatePermissionState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionState();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(C_BG);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(40));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("✓", 25, Color.WHITE, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(roundRect(C_BLUE, 12, 0));
        brand.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        titles.addView(text("Limpia Fácil", 24, C_TEXT, Typeface.BOLD));
        titles.addView(text("Analiza, explica y te deja decidir", 13, C_MUTED, Typeface.NORMAL));
        brand.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        root.addView(brand);

        addSpacer(18);
        permissionText = text("Revisando permiso de archivos…", 14, C_MUTED, Typeface.BOLD);
        permissionText.setPadding(dp(14), dp(12), dp(14), dp(12));
        permissionText.setBackground(roundRect(C_CARD, 10, 0));
        permissionText.setOnClickListener(v -> requestStorageAccess());
        root.addView(permissionText, matchWrap());

        addSpacer(8);
        usagePermissionText = text("Revisando permiso de uso de apps…", 14, C_MUTED, Typeface.BOLD);
        usagePermissionText.setPadding(dp(14), dp(12), dp(14), dp(12));
        usagePermissionText.setBackground(roundRect(C_CARD, 10, 0));
        usagePermissionText.setOnClickListener(v -> openUsageAccessSettings());
        root.addView(usagePermissionText, matchWrap());

        addSpacer(14);
        scanButton = button("ANALIZAR ARCHIVOS", C_BLUE, Color.rgb(2, 24, 33));
        scanButton.setOnClickListener(v -> startScan());
        root.addView(scanButton, matchHeight(52));

        addSpacer(8);
        LinearLayout analysisRow = new LinearLayout(this);
        analysisRow.setOrientation(LinearLayout.HORIZONTAL);
        ocrButton = button("Revisar capturas (OCR)", C_CARD_2, C_TEXT);
        ocrButton.setOnClickListener(v -> startOcrScan());
        analysisRow.addView(ocrButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        appsButton = button("Apps y memoria", C_CARD_2, C_TEXT);
        appsButton.setOnClickListener(v -> startAppsAnalysis());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(48), 1);
        ap.setMarginStart(dp(8));
        analysisRow.addView(appsButton, ap);
        root.addView(analysisRow);

        addSpacer(10);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        root.addView(progress, matchHeight(4));

        statusText = text("No he analizado nada todavía.", 13, C_MUTED, Typeface.NORMAL);
        statusText.setPadding(0, dp(8), 0, 0);
        root.addView(statusText);

        addSpacer(18);
        summaryText = text("Primero pulsa “Analizar archivos”.", 18, C_TEXT, Typeface.BOLD);
        summaryText.setPadding(dp(16), dp(16), dp(16), dp(16));
        summaryText.setBackground(roundRect(C_CARD, 12, 0));
        root.addView(summaryText, matchWrap());

        addSpacer(14);
        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.VERTICAL);
        cards.addView(categoryCard("🟡 Capturas de acceso remoto", "TeamViewer, AnyDesk, RustDesk, etc.", Category.REMOTE_SCREENSHOT, C_YELLOW));
        addInnerSpacer(cards, 8);
        cards.addView(categoryCard("🟢 Duplicados", "Copias exactas por contenido", Category.DUPLICATE, C_GREEN));
        addInnerSpacer(cards, 8);
        cards.addView(categoryCard("🟡 Archivos grandes", "Más de 500 MB", Category.LARGE, C_YELLOW));
        addInnerSpacer(cards, 8);
        cards.addView(categoryCard("🟡 Descargas viejas", "Más de 90 días en Descargas", Category.OLD_DOWNLOAD, C_YELLOW));
        addInnerSpacer(cards, 8);
        cards.addView(categoryCard("🟡 Capturas viejas", "Screenshots de más de 90 días", Category.OLD_SCREENSHOT, C_YELLOW));
        addInnerSpacer(cards, 8);
        cards.addView(categoryCard("🟡 APK / ZIP / RAR", "Instaladores y comprimidos", Category.ARCHIVE, C_YELLOW));
        addInnerSpacer(cards, 8);
        cards.addView(categoryCard("🔴 No tocar", "Carpetas privadas de Android", Category.PROTECTED, C_RED));
        root.addView(cards);

        addSpacer(18);
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        selectGreenButton = button("Seleccionar verdes", C_CARD_2, C_TEXT);
        selectGreenButton.setOnClickListener(v -> selectGreenCandidates());
        actionRow.addView(selectGreenButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        trashButton = button("Papelera", C_CARD_2, C_TEXT);
        trashButton.setOnClickListener(v -> showTrashDialog());
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(46), 1);
        tp.setMarginStart(dp(8));
        actionRow.addView(trashButton, tp);
        root.addView(actionRow);

        addSpacer(8);
        moveButton = button("ENVIAR SELECCIONADOS A PAPELERA", Color.rgb(26, 93, 115), C_TEXT);
        moveButton.setOnClickListener(v -> confirmMoveSelected());
        root.addView(moveButton, matchHeight(50));

        addSpacer(16);
        resultsContainer = new LinearLayout(this);
        resultsContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(resultsContainer);

        addSpacer(18);
        TextView privacy = text("Privacidad: el OCR se procesa en el teléfono. No guardo el texto detectado ni uso Internet.", 12, C_MUTED, Typeface.NORMAL);
        privacy.setPadding(dp(12), dp(12), dp(12), dp(12));
        privacy.setBackground(roundRect(C_CARD, 10, 0));
        root.addView(privacy);

        setContentView(scroll);
        updateButtons();
    }

    private View categoryCard(String title, String subtitle, String category, int accent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(13), dp(15), dp(13));
        card.setBackground(roundRect(C_CARD, 11, 0));
        TextView t = text(title, 16, C_TEXT, Typeface.BOLD);
        TextView s = text(subtitle, 12, C_MUTED, Typeface.NORMAL);
        TextView count = text("0", 20, accent, Typeface.BOLD);
        count.setTag("count_" + category);
        card.addView(t);
        card.addView(s);
        card.addView(count);
        card.setOnClickListener(v -> {
            activeCategory = category;
            renderResults(category);
        });
        return card;
    }

    private void updatePermissionState() {
        boolean filesOk = hasStorageAccess();
        permissionText.setText(filesOk ? "✓ Acceso a archivos permitido" : "⚠ Toca aquí para permitir acceso a tus archivos");
        permissionText.setTextColor(filesOk ? C_GREEN : C_YELLOW);

        boolean usageOk = AppUsageAnalyzer.hasUsageAccess(this);
        usagePermissionText.setText(usageOk ? "✓ Acceso de uso permitido (apps y almacenamiento)" : "⚠ Toca aquí para permitir ver uso de aplicaciones");
        usagePermissionText.setTextColor(usageOk ? C_GREEN : C_YELLOW);
        updateButtons();
    }

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStorageAccess() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 50);
            }
        } catch (Exception e) {
            Intent i = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
            startActivity(i);
        }
    }

    private void openUsageAccessSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "Abre Ajustes > Acceso especial > Acceso de uso.", Toast.LENGTH_LONG).show();
        }
    }

    private void startScan() {
        if (!hasStorageAccess()) {
            requestStorageAccess();
            return;
        }
        if (!scanning.compareAndSet(false, true)) return;

        allCandidates.clear();
        lastScannedFiles.clear();
        selectedPaths.clear();
        protectedFolders = 0;
        scannedBytes = 0;
        scannedFiles = 0;
        progress.setVisibility(View.VISIBLE);
        statusText.setText("Revisando tus archivos… todavía no estoy borrando nada.");
        summaryText.setText("Analizando…");
        clearCounts();
        resultsContainer.removeAllViews();
        updateButtons();

        executor.execute(() -> {
            try {
                ScanResult result = scanStorage();
                runOnUiThread(() -> finishScan(result));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    scanning.set(false);
                    progress.setVisibility(View.GONE);
                    statusText.setText("No pude terminar el análisis. No se borró nada.");
                    Toast.makeText(this, "Error al analizar: " + safeMessage(e), Toast.LENGTH_LONG).show();
                    updateButtons();
                });
            }
        });
    }

    private ScanResult scanStorage() throws Exception {
        File storage = Environment.getExternalStorageDirectory();
        List<FileInfo> files = new ArrayList<>();
        Deque<File> stack = new ArrayDeque<>();
        stack.push(storage);
        long now = System.currentTimeMillis();
        File trashRoot = getTrashRoot();
        String trashPath = trashRoot.getAbsolutePath();

        while (!stack.isEmpty()) {
            File dir = stack.pop();
            if (dir == null) continue;
            String dirPath = dir.getAbsolutePath();
            if (dirPath.startsWith(trashPath)) continue;
            if (isBlockedAndroidDir(dirPath, storage.getAbsolutePath())) {
                protectedFolders++;
                continue;
            }
            File[] children;
            try { children = dir.listFiles(); }
            catch (SecurityException se) { protectedFolders++; continue; }
            if (children == null) continue;
            for (File f : children) {
                try {
                    if (f.isDirectory()) {
                        stack.push(f);
                    } else if (f.isFile()) {
                        long size = Math.max(0, f.length());
                        FileInfo info = new FileInfo(f, size, f.lastModified());
                        files.add(info);
                        scannedFiles++;
                        scannedBytes += size;
                    }
                } catch (SecurityException ignored) {
                    protectedFolders++;
                }
            }
            if (scannedFiles % 500 == 0) {
                int count = scannedFiles;
                runOnUiThread(() -> statusText.setText("Revisados " + formatInt(count) + " archivos…"));
            }
        }

        synchronized (lastScannedFiles) {
            lastScannedFiles.clear();
            lastScannedFiles.addAll(files);
        }

        Map<Long, List<FileInfo>> bySize = new HashMap<>();
        for (FileInfo fi : files) {
            if (fi.size > 0) bySize.computeIfAbsent(fi.size, k -> new ArrayList<>()).add(fi);
        }

        Map<String, List<FileInfo>> duplicateGroups = new HashMap<>();
        int hashed = 0;
        for (Map.Entry<Long, List<FileInfo>> entry : bySize.entrySet()) {
            List<FileInfo> same = entry.getValue();
            if (same.size() < 2) continue;
            for (FileInfo fi : same) {
                String hash = sha256(fi.file);
                duplicateGroups.computeIfAbsent(fi.size + ":" + hash, k -> new ArrayList<>()).add(fi);
                hashed++;
                if (hashed % 50 == 0) {
                    int h = hashed;
                    runOnUiThread(() -> statusText.setText("Comparando contenido de archivos repetidos… " + formatInt(h)));
                }
            }
        }

        Set<String> duplicatePaths = new HashSet<>();
        long duplicateBytes = 0;
        for (List<FileInfo> group : duplicateGroups.values()) {
            if (group.size() < 2) continue;
            group.sort(Comparator.comparingLong(a -> a.modified <= 0 ? Long.MAX_VALUE : a.modified));
            for (int i = 1; i < group.size(); i++) {
                FileInfo fi = group.get(i);
                duplicatePaths.add(fi.file.getAbsolutePath());
                boolean appArea = isInsideAndroid(fi.file);
                String rec = appArea ? Recommendation.YELLOW : Recommendation.GREEN;
                String reason = appArea
                        ? "Es duplicado exacto, pero está dentro de una carpeta usada por una app. Revísalo."
                        : "Es una copia exacta de otro archivo. Se conservará al menos una copia.";
                allCandidates.add(new Candidate(fi.file, Category.DUPLICATE, rec, reason));
                duplicateBytes += fi.size;
            }
        }

        for (FileInfo fi : files) {
            String path = fi.file.getAbsolutePath();
            String lower = fi.file.getName().toLowerCase(Locale.ROOT);
            if (fi.size >= LARGE_BYTES && !duplicatePaths.contains(path)) {
                allCandidates.add(new Candidate(fi.file, Category.LARGE, Recommendation.YELLOW,
                        "Ocupa mucho espacio. Ábrelo o identifica qué es antes de borrarlo."));
            }
            if (isInDownloads(fi.file) && fi.modified > 0 && now - fi.modified >= OLD_DOWNLOAD_MS && !duplicatePaths.contains(path)) {
                allCandidates.add(new Candidate(fi.file, Category.OLD_DOWNLOAD, Recommendation.YELLOW,
                        "Está en Descargas y lleva más de 90 días sin modificarse."));
            }
            if (isScreenshot(fi.file) && fi.modified > 0 && now - fi.modified >= OLD_SCREENSHOT_MS && !duplicatePaths.contains(path)) {
                allCandidates.add(new Candidate(fi.file, Category.OLD_SCREENSHOT, Recommendation.YELLOW,
                        "Parece una captura de pantalla y tiene más de 90 días."));
            }
            if (isArchiveOrApk(lower) && !duplicatePaths.contains(path)) {
                allCandidates.add(new Candidate(fi.file, Category.ARCHIVE, Recommendation.YELLOW,
                        lower.endsWith(".apk") ? "Es un instalador APK; borrar el archivo no desinstala la app." : "Es un archivo comprimido. Revisa si todavía lo necesitas."));
            }
        }

        allCandidates.sort((a, b) -> Long.compare(b.file.length(), a.file.length()));
        return new ScanResult(files.size(), scannedBytes, duplicateBytes);
    }

    private void finishScan(ScanResult result) {
        scanning.set(false);
        progress.setVisibility(View.GONE);
        statusText.setText("Listo. Revisé " + formatInt(result.files) + " archivos (" + formatBytes(result.bytes) + "). No borré nada.");
        long recoverable = 0;
        int greenCount = 0;
        synchronized (allCandidates) {
            for (Candidate c : allCandidates) {
                if (Recommendation.GREEN.equals(c.recommendation)) {
                    recoverable += c.file.length();
                    greenCount++;
                }
            }
        }
        summaryText.setText(greenCount == 0
                ? "No encontré copias exactas claramente seguras. Puedes revisar archivos grandes, capturas viejas y después ejecutar OCR."
                : "Puedes recuperar al menos " + formatBytes(recoverable) + " quitando " + greenCount + " duplicado(s) exacto(s). Lo amarillo requiere revisión.");
        updateCounts();
        activeCategory = Category.REMOTE_SCREENSHOT;
        renderResults(activeCategory);
        updateButtons();
    }

    private void startOcrScan() {
        if (!hasStorageAccess()) {
            requestStorageAccess();
            return;
        }
        if (!ocrScanning.compareAndSet(false, true)) return;

        progress.setVisibility(View.VISIBLE);
        statusText.setText("Preparando imágenes para OCR…");
        removeCategory(Category.REMOTE_SCREENSHOT);
        setCount(Category.REMOTE_SCREENSHOT, 0);
        updateButtons();

        executor.execute(() -> {
            try {
                List<FileInfo> source = getOcrSourceFiles();
                source.sort((a, b) -> Integer.compare(ocrPriority(a.file), ocrPriority(b.file)));
                int limit = Math.min(MAX_OCR_IMAGES, source.size());
                int found = 0;
                try (OcrHelper helper = new OcrHelper()) {
                    for (int i = 0; i < limit; i++) {
                        FileInfo fi = source.get(i);
                        if (!fi.file.exists() || fi.size <= 0 || fi.size > 25L * 1024L * 1024L) continue;
                        try {
                            OcrHelper.Finding finding = helper.analyze(fi.file);
                            if (finding.remoteAccess) {
                                String apps = TextUtils.join(", ", finding.products);
                                long ageDays = fi.modified <= 0 ? -1 : Math.max(0, (System.currentTimeMillis() - fi.modified) / (24L * 60L * 60L * 1000L));
                                String age = ageDays >= 0 ? " · " + ageDays + " días" : "";
                                allCandidates.add(new Candidate(fi.file, Category.REMOTE_SCREENSHOT, Recommendation.YELLOW,
                                        "Detecté texto de " + apps + age + ". La app no guarda IDs, contraseñas ni el texto leído."));
                                found++;
                            }
                        } catch (Throwable ignored) {
                        }
                        if (i % 15 == 0) {
                            int pos = i + 1;
                            runOnUiThread(() -> statusText.setText("OCR: " + pos + " de " + limit + " imágenes…"));
                        }
                    }
                }
                final int foundFinal = found;
                final int checkedFinal = limit;
                runOnUiThread(() -> {
                    ocrScanning.set(false);
                    progress.setVisibility(View.GONE);
                    statusText.setText("OCR listo. Revisé " + checkedFinal + " imagen(es) y encontré " + foundFinal + " posible(s) captura(s) de acceso remoto.");
                    updateCounts();
                    activeCategory = Category.REMOTE_SCREENSHOT;
                    renderResults(activeCategory);
                    updateButtons();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    ocrScanning.set(false);
                    progress.setVisibility(View.GONE);
                    statusText.setText("No pude completar el OCR. No se borró nada.");
                    updateButtons();
                });
            }
        });
    }

    private List<FileInfo> getOcrSourceFiles() {
        List<FileInfo> source = new ArrayList<>();
        synchronized (lastScannedFiles) {
            for (FileInfo fi : lastScannedFiles) if (isOcrImageCandidate(fi.file)) source.add(fi);
        }
        if (!source.isEmpty()) return source;

        File storage = Environment.getExternalStorageDirectory();
        Deque<File> stack = new ArrayDeque<>();
        stack.push(storage);
        String trashPath = getTrashRoot().getAbsolutePath();
        while (!stack.isEmpty()) {
            File dir = stack.pop();
            if (dir == null) continue;
            String path = dir.getAbsolutePath();
            if (path.startsWith(trashPath) || isBlockedAndroidDir(path, storage.getAbsolutePath())) continue;
            File[] children;
            try { children = dir.listFiles(); } catch (Exception e) { continue; }
            if (children == null) continue;
            for (File f : children) {
                if (f.isDirectory()) stack.push(f);
                else if (f.isFile() && isOcrImageCandidate(f)) source.add(new FileInfo(f, f.length(), f.lastModified()));
            }
        }
        return source;
    }

    private int ocrPriority(File file) {
        String p = file.getAbsolutePath().toLowerCase(Locale.ROOT);
        String n = file.getName().toLowerCase(Locale.ROOT);
        if (n.contains("screenshot") || n.contains("captura") || p.contains("/screenshots/")) return 0;
        if (p.contains("/download/") || p.contains("/downloads/")) return 1;
        if (p.contains("whatsapp images") || p.contains("telegram")) return 2;
        return 3;
    }

    private void startAppsAnalysis() {
        AppUsageAnalyzer.DeviceStats device = AppUsageAnalyzer.deviceStats(this);
        if (!AppUsageAnalyzer.hasUsageAccess(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Falta un permiso")
                    .setMessage("Para saber qué apps ocupan más espacio y cuáles casi no usas, Android pide “Acceso de uso”. No permite borrar ni leer tus conversaciones.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Dar permiso", (d, w) -> openUsageAccessSettings())
                    .show();
            return;
        }
        if (!appScanning.compareAndSet(false, true)) return;
        progress.setVisibility(View.VISIBLE);
        statusText.setText("Calculando almacenamiento y uso de aplicaciones…");
        updateButtons();

        executor.execute(() -> {
            try {
                List<AppUsageAnalyzer.AppRow> rows = AppUsageAnalyzer.analyze(this);
                runOnUiThread(() -> {
                    appScanning.set(false);
                    progress.setVisibility(View.GONE);
                    statusText.setText("Apps analizadas: " + formatInt(rows.size()) + ".");
                    showAppsDialog(device, rows);
                    updateButtons();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    appScanning.set(false);
                    progress.setVisibility(View.GONE);
                    Toast.makeText(this, "No pude leer el uso de apps. Revisa el permiso de uso.", Toast.LENGTH_LONG).show();
                    updateButtons();
                });
            }
        });
    }

    private void showAppsDialog(AppUsageAnalyzer.DeviceStats device, List<AppUsageAnalyzer.AppRow> rows) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), dp(10), dp(14), dp(18));
        scroll.addView(list);

        long usedStorage = Math.max(0, device.totalStorage - device.freeStorage);
        long usedRam = Math.max(0, device.totalRam - device.availableRam);
        list.addView(dialogCard("Almacenamiento", formatBytes(usedStorage) + " usados de " + formatBytes(device.totalStorage)));
        addInnerSpacer(list, 8);
        list.addView(dialogCard("RAM ahora", formatBytes(usedRam) + " usada · " + formatBytes(device.availableRam) + " disponible"));
        addInnerSpacer(list, 8);
        TextView note = text("Android no permite a una app normal medir con precisión la RAM de cada otra app. Para decidir qué desactivar usamos almacenamiento, caché y último uso.", 12, C_MUTED, Typeface.NORMAL);
        note.setPadding(dp(12), dp(12), dp(12), dp(12));
        note.setBackground(roundRect(C_CARD, 10, 0));
        list.addView(note);

        addInnerSpacer(list, 14);
        list.addView(text("Apps que más ocupan", 17, C_TEXT, Typeface.BOLD));
        int heavy = Math.min(30, rows.size());
        for (int i = 0; i < heavy; i++) {
            AppUsageAnalyzer.AppRow row = rows.get(i);
            if (row.totalBytes <= 0) continue;
            addInnerSpacer(list, 7);
            list.addView(appRowView(row, false));
        }

        List<AppUsageAnalyzer.AppRow> unused = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (AppUsageAnalyzer.AppRow row : rows) if (row.unused90Days(now)) unused.add(row);
        unused.sort(Comparator.comparingLong((AppUsageAnalyzer.AppRow a) -> a.totalBytes).reversed());

        addInnerSpacer(list, 16);
        list.addView(text("Apps sin usar por 90+ días", 17, C_TEXT, Typeface.BOLD));
        if (unused.isEmpty()) {
            addInnerSpacer(list, 7);
            list.addView(text("No encontré candidatas claras.", 13, C_MUTED, Typeface.NORMAL));
        } else {
            int n = Math.min(30, unused.size());
            for (int i = 0; i < n; i++) {
                addInnerSpacer(list, 7);
                list.addView(appRowView(unused.get(i), true));
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Apps y memoria")
                .setView(scroll)
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private View dialogCard(String title, String value) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(11), dp(12), dp(11));
        card.setBackground(roundRect(C_CARD, 10, 0));
        card.addView(text(title, 12, C_MUTED, Typeface.BOLD));
        card.addView(text(value, 16, C_TEXT, Typeface.BOLD));
        return card;
    }

    private View appRowView(AppUsageAnalyzer.AppRow row, boolean unused) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(11), dp(12), dp(11));
        card.setBackground(roundRect(C_CARD, 10, 0));
        card.addView(text(row.label, 14, C_TEXT, Typeface.BOLD));
        String size = row.totalBytes > 0 ? formatBytes(row.totalBytes) : "tamaño no disponible";
        String cache = row.cacheBytes > 0 ? " · caché " + formatBytes(row.cacheBytes) : "";
        card.addView(text(size + cache, 12, unused ? C_YELLOW : C_BLUE, Typeface.BOLD));
        String last = row.lastUsed > 0 ? "Último uso: " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(row.lastUsed)) : "Sin uso registrado en el último año";
        card.addView(text(last, 11, C_MUTED, Typeface.NORMAL));
        Button manage = button("Administrar / desactivar", C_CARD_2, C_TEXT);
        manage.setOnClickListener(v -> openAppSettings(row.packageName));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42));
        mp.topMargin = dp(7);
        card.addView(manage, mp);
        return card;
    }

    private void openAppSettings(String packageName) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + packageName));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No pude abrir la configuración de esa app.", Toast.LENGTH_SHORT).show();
        }
    }

    private void renderResults(String category) {
        resultsContainer.removeAllViews();
        TextView heading = text(categoryTitle(category), 18, C_TEXT, Typeface.BOLD);
        heading.setPadding(0, 0, 0, dp(8));
        resultsContainer.addView(heading);

        if (Category.PROTECTED.equals(category)) {
            TextView p = text("No escaneo Android/data ni Android/obb. Son carpetas privadas de aplicaciones y esta app no intentará limpiarlas. Carpetas protegidas/no accesibles detectadas: " + protectedFolders + ".", 14, C_MUTED, Typeface.NORMAL);
            p.setPadding(dp(14), dp(14), dp(14), dp(14));
            p.setBackground(roundRect(C_CARD, 10, 0));
            resultsContainer.addView(p);
            return;
        }

        if (Category.REMOTE_SCREENSHOT.equals(category) && countCategory(category) == 0) {
            TextView hint = text("Pulsa “Revisar capturas (OCR)”. Buscaré texto de TeamViewer, AnyDesk, RustDesk, Supremo y similares sin guardar el ID ni la contraseña detectada.", 13, C_MUTED, Typeface.NORMAL);
            hint.setPadding(dp(14), dp(14), dp(14), dp(14));
            hint.setBackground(roundRect(C_CARD, 10, 0));
            resultsContainer.addView(hint);
            return;
        }

        List<Candidate> items = new ArrayList<>();
        synchronized (allCandidates) {
            for (Candidate c : allCandidates) if (category.equals(c.category) && c.file.exists()) items.add(c);
        }
        if (items.isEmpty()) {
            TextView empty = text("Nada por aquí.", 14, C_MUTED, Typeface.NORMAL);
            empty.setPadding(dp(14), dp(14), dp(14), dp(14));
            empty.setBackground(roundRect(C_CARD, 10, 0));
            resultsContainer.addView(empty);
            return;
        }

        int visible = Math.min(MAX_VISIBLE, items.size());
        for (int i = 0; i < visible; i++) {
            Candidate c = items.get(i);
            resultsContainer.addView(candidateRow(c));
            addInnerSpacer(resultsContainer, 7);
        }
        if (items.size() > visible) {
            resultsContainer.addView(text("Mostrando " + visible + " de " + items.size() + " para no volver lenta la pantalla.", 12, C_MUTED, Typeface.NORMAL));
        }
    }

    private View candidateRow(Candidate c) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setPadding(dp(12), dp(11), dp(12), dp(11));
        row.setBackground(roundRect(C_CARD, 10, 0));

        CheckBox cb = new CheckBox(this);
        cb.setChecked(selectedPaths.contains(c.file.getAbsolutePath()));
        cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) selectedPaths.add(c.file.getAbsolutePath());
            else selectedPaths.remove(c.file.getAbsolutePath());
            updateButtons();
        });
        row.addView(cb, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        TextView name = text(c.file.getName(), 14, C_TEXT, Typeface.BOLD);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(name);
        int riskColor = Recommendation.GREEN.equals(c.recommendation) ? C_GREEN : C_YELLOW;
        info.addView(text((Recommendation.GREEN.equals(c.recommendation) ? "PUEDES BORRAR · " : "REVISA · ") + formatBytes(c.file.length()), 12, riskColor, Typeface.BOLD));
        TextView reason = text(c.reason, 12, C_MUTED, Typeface.NORMAL);
        reason.setPadding(0, dp(3), 0, 0);
        info.addView(reason);
        TextView path = text(shortPath(c.file), 11, Color.rgb(112, 132, 153), Typeface.NORMAL);
        path.setPadding(0, dp(4), 0, 0);
        info.addView(path);
        row.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        return row;
    }

    private void selectGreenCandidates() {
        int count = 0;
        synchronized (allCandidates) {
            for (Candidate c : allCandidates) {
                if (Recommendation.GREEN.equals(c.recommendation) && c.file.exists()) {
                    selectedPaths.add(c.file.getAbsolutePath());
                    count++;
                }
            }
        }
        Toast.makeText(this, count == 0 ? "No hay archivos verdes." : "Seleccionados " + count + " archivo(s) verdes.", Toast.LENGTH_SHORT).show();
        renderResults(activeCategory);
        updateButtons();
    }

    private void confirmMoveSelected() {
        List<File> selected = selectedExistingFiles();
        if (selected.isEmpty()) {
            Toast.makeText(this, "No has seleccionado archivos.", Toast.LENGTH_SHORT).show();
            return;
        }
        long bytes = 0;
        for (File f : selected) bytes += f.length();
        final long totalBytes = bytes;
        new AlertDialog.Builder(this)
                .setTitle("¿Mandar a papelera?")
                .setMessage("Moveré " + selected.size() + " archivo(s) (" + formatBytes(totalBytes) + ") a la papelera de Limpia Fácil. Podrás restaurarlos después.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Mandar a papelera", (d, w) -> moveFilesToTrash(selected))
                .show();
    }

    private void moveFilesToTrash(List<File> files) {
        progress.setVisibility(View.VISIBLE);
        moveButton.setEnabled(false);
        executor.execute(() -> {
            int moved = 0;
            long bytes = 0;
            JSONObject trashMap = loadTrashMap();
            File trashRoot = getTrashRoot();
            if (!trashRoot.exists()) trashRoot.mkdirs();
            for (File src : files) {
                if (!src.exists()) continue;
                long len = src.length();
                try {
                    File dst = uniqueTrashFile(trashRoot, src.getName());
                    if (moveFile(src, dst)) {
                        trashMap.put(dst.getAbsolutePath(), src.getAbsolutePath());
                        selectedPaths.remove(src.getAbsolutePath());
                        moved++;
                        bytes += len;
                    }
                } catch (Exception ignored) {
                }
            }
            saveTrashMap(trashMap);
            final int movedFinal = moved;
            final long bytesFinal = bytes;
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                Toast.makeText(this, "A papelera: " + movedFinal + " archivo(s), " + formatBytes(bytesFinal), Toast.LENGTH_LONG).show();
                removeMissingCandidates();
                updateCounts();
                renderResults(activeCategory);
                updateButtons();
            });
        });
    }

    private void showTrashDialog() {
        JSONObject map = loadTrashMap();
        List<String> trashPaths = new ArrayList<>();
        for (java.util.Iterator<String> it = map.keys(); it.hasNext();) {
            String p = it.next();
            if (new File(p).exists()) trashPaths.add(p);
        }
        if (trashPaths.isEmpty()) {
            Toast.makeText(this, "La papelera está vacía.", Toast.LENGTH_SHORT).show();
            return;
        }
        trashPaths.sort(String::compareToIgnoreCase);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), dp(8), dp(14), dp(8));
        scroll.addView(list);
        int visible = Math.min(80, trashPaths.size());
        for (int i = 0; i < visible; i++) {
            String trashPath = trashPaths.get(i);
            String original = map.optString(trashPath, "");
            File f = new File(trashPath);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, dp(8), 0, dp(8));
            row.addView(text(f.getName() + " · " + formatBytes(f.length()), 13, C_TEXT, Typeface.BOLD));
            row.addView(text("Antes: " + original, 11, C_MUTED, Typeface.NORMAL));
            Button restore = button("Restaurar", C_CARD_2, C_TEXT);
            restore.setOnClickListener(v -> restoreFromTrash(trashPath, original));
            row.addView(restore, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)));
            list.addView(row);
        }
        new AlertDialog.Builder(this)
                .setTitle("Papelera de Limpia Fácil")
                .setView(scroll)
                .setNegativeButton("Cerrar", null)
                .setPositiveButton("Vaciar papelera", (d, w) -> confirmEmptyTrash())
                .show();
    }

    private void restoreFromTrash(String trashPath, String originalPath) {
        if (TextUtils.isEmpty(originalPath)) return;
        File src = new File(trashPath);
        File dst = new File(originalPath);
        try {
            File parent = dst.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            if (dst.exists()) dst = uniqueSibling(dst);
            if (moveFile(src, dst)) {
                JSONObject map = loadTrashMap();
                map.remove(trashPath);
                saveTrashMap(map);
                Toast.makeText(this, "Restaurado en: " + shortPath(dst), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "No pude restaurarlo.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "No pude restaurarlo.", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmEmptyTrash() {
        new AlertDialog.Builder(this)
                .setTitle("Vaciar papelera")
                .setMessage("Esto sí elimina definitivamente los archivos de la papelera. ¿Continuar?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar definitivamente", (d, w) -> emptyTrash())
                .show();
    }

    private void emptyTrash() {
        JSONObject map = loadTrashMap();
        int removed = 0;
        for (java.util.Iterator<String> it = map.keys(); it.hasNext();) {
            String p = it.next();
            File f = new File(p);
            if (!f.exists() || f.delete()) removed++;
        }
        saveTrashMap(new JSONObject());
        Toast.makeText(this, "Papelera vaciada: " + removed + " archivo(s).", Toast.LENGTH_LONG).show();
    }

    private boolean moveFile(File src, File dst) throws Exception {
        if (src.renameTo(dst)) return true;
        try (InputStream in = new BufferedInputStream(new FileInputStream(src));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(dst))) {
            byte[] buffer = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        }
        if (dst.length() != src.length()) {
            dst.delete();
            return false;
        }
        return src.delete();
    }

    private JSONObject loadTrashMap() {
        try {
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            return new JSONObject(p.getString(PREF_TRASH, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void saveTrashMap(JSONObject map) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_TRASH, map.toString()).apply();
    }

    private File getTrashRoot() {
        return new File(Environment.getExternalStorageDirectory(), "Documents/LimpiaFacil_Papelera");
    }

    private File uniqueTrashFile(File root, String name) {
        String stamp = String.valueOf(System.currentTimeMillis());
        File f = new File(root, stamp + "_" + name);
        int n = 1;
        while (f.exists()) f = new File(root, stamp + "_" + n++ + "_" + name);
        return f;
    }

    private File uniqueSibling(File dst) {
        File parent = dst.getParentFile();
        String name = dst.getName();
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        int n = 1;
        File out = dst;
        while (out.exists()) out = new File(parent, base + "_restaurado_" + n++ + ext);
        return out;
    }

    private void removeMissingCandidates() {
        synchronized (allCandidates) {
            allCandidates.removeIf(c -> !c.file.exists());
        }
    }

    private void removeCategory(String category) {
        synchronized (allCandidates) {
            allCandidates.removeIf(c -> category.equals(c.category));
        }
    }

    private List<File> selectedExistingFiles() {
        List<File> list = new ArrayList<>();
        synchronized (selectedPaths) {
            for (String p : selectedPaths) {
                File f = new File(p);
                if (f.exists() && f.isFile()) list.add(f);
            }
        }
        return list;
    }

    private String sha256(File file) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new BufferedInputStream(new FileInputStream(file), 1024 * 1024)) {
            byte[] buffer = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) md.update(buffer, 0, n);
        }
        byte[] digest = md.digest();
        StringBuilder sb = new StringBuilder(64);
        for (byte b : digest) sb.append(String.format(Locale.US, "%02x", b));
        return sb.toString();
    }

    private boolean isBlockedAndroidDir(String path, String storageRoot) {
        String rel = path.substring(Math.min(path.length(), storageRoot.length())).replace('\\', '/').toLowerCase(Locale.ROOT);
        return rel.equals("/android/data") || rel.startsWith("/android/data/") || rel.equals("/android/obb") || rel.startsWith("/android/obb/");
    }

    private boolean isInsideAndroid(File f) {
        String p = f.getAbsolutePath().replace('\\', '/').toLowerCase(Locale.ROOT);
        return p.contains("/android/");
    }

    private boolean isInDownloads(File f) {
        String p = f.getAbsolutePath().replace('\\', '/').toLowerCase(Locale.ROOT);
        return p.contains("/download/") || p.endsWith("/download") || p.contains("/downloads/");
    }

    private boolean isScreenshot(File f) {
        String p = f.getAbsolutePath().replace('\\', '/').toLowerCase(Locale.ROOT);
        String n = f.getName().toLowerCase(Locale.ROOT);
        return p.contains("/screenshots/") || n.contains("screenshot") || n.contains("captura_de_pantalla") || n.contains("captura de pantalla");
    }

    private boolean isOcrImageCandidate(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        if (!(n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp"))) return false;
        String p = f.getAbsolutePath().replace('\\', '/').toLowerCase(Locale.ROOT);
        return isScreenshot(f) || isInDownloads(f) || p.contains("whatsapp images") || p.contains("/telegram/") || p.contains("/pictures/");
    }

    private boolean isArchiveOrApk(String lower) {
        return lower.endsWith(".apk") || lower.endsWith(".zip") || lower.endsWith(".rar") || lower.endsWith(".7z") || lower.endsWith(".tar") || lower.endsWith(".gz");
    }

    private void updateCounts() {
        setCount(Category.REMOTE_SCREENSHOT, countCategory(Category.REMOTE_SCREENSHOT));
        setCount(Category.DUPLICATE, countCategory(Category.DUPLICATE));
        setCount(Category.LARGE, countCategory(Category.LARGE));
        setCount(Category.OLD_DOWNLOAD, countCategory(Category.OLD_DOWNLOAD));
        setCount(Category.OLD_SCREENSHOT, countCategory(Category.OLD_SCREENSHOT));
        setCount(Category.ARCHIVE, countCategory(Category.ARCHIVE));
        setCount(Category.PROTECTED, protectedFolders);
    }

    private void clearCounts() {
        setCount(Category.REMOTE_SCREENSHOT, 0);
        setCount(Category.DUPLICATE, 0);
        setCount(Category.LARGE, 0);
        setCount(Category.OLD_DOWNLOAD, 0);
        setCount(Category.OLD_SCREENSHOT, 0);
        setCount(Category.ARCHIVE, 0);
        setCount(Category.PROTECTED, 0);
    }

    private int countCategory(String cat) {
        int n = 0;
        synchronized (allCandidates) {
            for (Candidate c : allCandidates) if (cat.equals(c.category) && c.file.exists()) n++;
        }
        return n;
    }

    private void setCount(String category, int count) {
        View v = findViewWithTagRecursive(root, "count_" + category);
        if (v instanceof TextView) ((TextView) v).setText(formatInt(count));
    }

    private View findViewWithTagRecursive(View view, Object tag) {
        if (tag.equals(view.getTag())) return view;
        if (view instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) view;
            for (int i = 0; i < g.getChildCount(); i++) {
                View found = findViewWithTagRecursive(g.getChildAt(i), tag);
                if (found != null) return found;
            }
        }
        return null;
    }

    private void updateButtons() {
        boolean busy = scanning.get() || ocrScanning.get() || appScanning.get();
        boolean filesOk = hasStorageAccess();
        int n = selectedExistingFiles().size();
        scanButton.setEnabled(filesOk && !busy);
        ocrButton.setEnabled(filesOk && !busy);
        appsButton.setEnabled(!busy);
        moveButton.setText(n == 0 ? "ENVIAR SELECCIONADOS A PAPELERA" : "A PAPELERA · " + n + " SELECCIONADO(S)");
        moveButton.setEnabled(!busy && n > 0);
        selectGreenButton.setEnabled(!busy);
        trashButton.setEnabled(!busy);
    }

    private String categoryTitle(String category) {
        switch (category) {
            case Category.REMOTE_SCREENSHOT: return "Capturas de acceso remoto";
            case Category.DUPLICATE: return "Duplicados exactos";
            case Category.LARGE: return "Archivos grandes";
            case Category.OLD_DOWNLOAD: return "Descargas viejas";
            case Category.OLD_SCREENSHOT: return "Capturas viejas";
            case Category.ARCHIVE: return "APK y comprimidos";
            case Category.PROTECTED: return "No tocar";
            default: return "Resultados";
        }
    }

    private String shortPath(File file) {
        String rootPath = Environment.getExternalStorageDirectory().getAbsolutePath();
        String p = file.getAbsolutePath();
        if (p.startsWith(rootPath)) p = p.substring(rootPath.length());
        if (p.length() > 90) p = "…" + p.substring(p.length() - 89);
        return p;
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        return TextUtils.isEmpty(m) ? "error inesperado" : m;
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double v = bytes;
        String[] u = {"B", "KB", "MB", "GB", "TB"};
        int i = 0;
        while (v >= 1024 && i < u.length - 1) { v /= 1024.0; i++; }
        return String.format(Locale.getDefault(), v >= 10 ? "%.1f %s" : "%.2f %s", v, u[i]);
    }

    private String formatInt(int n) {
        return String.format(Locale.getDefault(), "%,d", n);
    }

    private TextView text(String value, int sp, int color, int style) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setTypeface(Typeface.create("sans", style));
        return tv;
    }

    private Button button(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans", Typeface.BOLD));
        b.setBackground(roundRect(bg, 10, 0));
        b.setPadding(dp(12), 0, dp(12), 0);
        return b;
    }

    private GradientDrawable roundRect(int fill, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchHeight(int heightDp) {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp));
    }

    private void addSpacer(int valueDp) {
        View v = new View(this);
        root.addView(v, new LinearLayout.LayoutParams(1, dp(valueDp)));
    }

    private void addInnerSpacer(LinearLayout parent, int valueDp) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(valueDp)));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    static final class Category {
        static final String REMOTE_SCREENSHOT = "remote_screenshot";
        static final String DUPLICATE = "duplicate";
        static final String LARGE = "large";
        static final String OLD_DOWNLOAD = "old_download";
        static final String OLD_SCREENSHOT = "old_screenshot";
        static final String ARCHIVE = "archive";
        static final String PROTECTED = "protected";
    }

    static final class Recommendation {
        static final String GREEN = "green";
        static final String YELLOW = "yellow";
    }

    static final class Candidate {
        final File file;
        final String category;
        final String recommendation;
        final String reason;

        Candidate(File file, String category, String recommendation, String reason) {
            this.file = file;
            this.category = category;
            this.recommendation = recommendation;
            this.reason = reason;
        }
    }

    static final class FileInfo {
        final File file;
        final long size;
        final long modified;

        FileInfo(File file, long size, long modified) {
            this.file = file;
            this.size = size;
            this.modified = modified;
        }
    }

    static final class ScanResult {
        final int files;
        final long bytes;
        final long duplicateBytes;

        ScanResult(int files, long bytes, long duplicateBytes) {
            this.files = files;
            this.bytes = bytes;
            this.duplicateBytes = duplicateBytes;
        }
    }
}
