package com.limpiafacil.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class OcrHelper implements AutoCloseable {
    private final TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

    static final class Finding {
        final boolean remoteAccess;
        final List<String> products;

        Finding(boolean remoteAccess, List<String> products) {
            this.remoteAccess = remoteAccess;
            this.products = products;
        }
    }

    Finding analyze(File file) throws Exception {
        Bitmap bitmap = decodeScaled(file, 1800);
        if (bitmap == null) return new Finding(false, new ArrayList<>());
        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            Text result = Tasks.await(recognizer.process(image));
            String normalized = normalize(result.getText());
            List<String> products = new ArrayList<>();
            addIfFound(normalized, products, "teamviewer", "TeamViewer");
            addIfFound(normalized, products, "anydesk", "AnyDesk");
            addIfFound(normalized, products, "rustdesk", "RustDesk");
            addIfFound(normalized, products, "supremo", "Supremo");
            addIfFound(normalized, products, "ultraviewer", "UltraViewer");
            addIfFound(normalized, products, "quickassist", "Asistencia rápida");
            addIfFound(normalized, products, "asistenciarapida", "Asistencia rápida");
            addIfFound(normalized, products, "remotedesktop", "Escritorio remoto");
            return new Finding(!products.isEmpty(), products);
        } finally {
            bitmap.recycle();
        }
    }

    private static void addIfFound(String normalized, List<String> out, String token, String label) {
        if (normalized.contains(token) && !out.contains(label)) out.add(label);
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT)
                .replace("á", "a").replace("é", "e").replace("í", "i")
                .replace("ó", "o").replace("ú", "u").replace("ü", "u")
                .replaceAll("[^a-z0-9]", "");
    }

    private static Bitmap decodeScaled(File file, int maxDimension) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        int sample = 1;
        int max = Math.max(bounds.outWidth, bounds.outHeight);
        while (max / sample > maxDimension) sample *= 2;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = Math.max(1, sample);
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
    }

    @Override
    public void close() {
        recognizer.close();
    }
}
